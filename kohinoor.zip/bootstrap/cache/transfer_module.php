<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Transfer\\Providers\\TransferServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Transfer\\Providers\\TransferServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);