<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateASMSTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('asms', function (Blueprint $table) {
            $table->id();
            $table->string('name',50);
            $table->string('username',30)->unique();
            $table->string('phone',15)->unique();
            $table->string('email')->nullable();
            $table->string('avatar')->nullable();
            $table->string('password');
            $table->unsignedBigInteger('district_id');
            $table->foreign('district_id')->references('id')->on('locations');
            $table->text('address')->nullable();
            $table->string('nid_no')->nullable();
            $table->double('monthly_target_value')->nullable();
            $table->enum('status',['1','2'])->default('1')->comment = "1=Active, 2=Inactive";
            $table->string('created_by')->nullable();
            $table->string('modified_by')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('asms');
    }
}