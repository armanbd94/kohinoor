<div class="modal fade" id="view_modal" tabindex="-1" role="dialog" aria-labelledby="model-1" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">

      <!-- Modal Content -->
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header bg-primary">
          <h3 class="modal-title text-white" id="model-1"><i class="fas fa-eye text-white"></i> <span>Sales Person Details</span></h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <i aria-hidden="true" class="ki ki-close text-white"></i>
          </button>
        </div>
        <!-- /modal header -->

        <!-- Modal Body -->
        <div class="modal-body">
            <div class="row" id="view-data">
                
            </div>
        </div>
        <!-- /modal body -->

        <!-- Modal Footer -->
        <div class="modal-footer">
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
        </div>
        <!-- /modal footer -->
      </div>
      <!-- /modal content -->

    </div>
  </div>